package com.zybooks.classproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

public class UserDatabase extends SQLiteOpenHelper {
    //Database name

    private static final String DB_NAME = "User.db";
    //database version
    private static final int DB_VERSION = 1;

    private static UserDatabase mUserDB;

    public static UserDatabase getInstance(Context context) {
        if (mUserDB == null) {
            mUserDB = new UserDatabase(context);
        }
        return mUserDB;
    }

    public UserDatabase(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    private static final class UserDB {
        //table of inventory
        public static final String TABLE_USER = "user";
        //username column
        private static final String NAME_COL = "username";
        //password column
        private static final String PASSWORD_COL = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + UserDB.TABLE_USER + " (" +
                UserDB.NAME_COL + " text," +
                UserDB.PASSWORD_COL + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists " + UserDB.TABLE_USER);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    //CRUD - R
    public List<User> getUsers() {
        List<User> users = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + UserDB.TABLE_USER;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            do {
                User us = new User();
                us.setID(cursor.getInt(0));
                us.setUserName(cursor.getString(1));
                us.setPassword(cursor.getString(3));
                users.add(us);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return users;
    }

    //CRUD - C
    public boolean addUser(String userName, String password){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserDB.NAME_COL,userName);
        values.put(UserDB.PASSWORD_COL,password);

        long id = db.insert(UserDB.TABLE_USER, null, values);
        return id != -1;
    }

    //CRUD - U
    public void updateUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDB.NAME_COL, user.getUserName());
        values.put(UserDB.PASSWORD_COL, user.getPassword());
        db.update(UserDB.TABLE_USER, values,
                UserDB.NAME_COL + " = ?", new String[] {user.getUserName()});
    }

    //CRUD - D
    public void deleteUser(String userName) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(UserDB.TABLE_USER,UserDB.NAME_COL + " = " + userName, null);
    }

    public boolean checkUser(String username) {
        // array of columns to fetch
        String[] columns = {
                UserDB.NAME_COL
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = UserDB.NAME_COL + " = ?";
        // selection argument
        String[] selectionArgs = {username};
        // query user table with condition

        Cursor cursor = db.query(UserDB.TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }
        return false;
    }

    public boolean checkUserPassword(String username, String password){
        // array of columns to fetch
        String[] columns = {
                UserDB.NAME_COL
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = UserDB.NAME_COL + " = ?" + " AND " + UserDB.PASSWORD_COL + " = ?";
        // selection argument
        String[] selectionArgs = {username,password};
        // query user table with condition
        Cursor cursor = db.query(UserDB.TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();

        cursor.close();
        if(cursorCount > 0){
            return true;
        }
        return false;
    }
}
