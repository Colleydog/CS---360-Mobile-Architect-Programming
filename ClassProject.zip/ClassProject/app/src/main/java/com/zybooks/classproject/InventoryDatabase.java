package com.zybooks.classproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {
    //Database name

    private static final String DB_NAME = "Inventory.db";
    //database version
    private static final int DB_VERSION = 1;
    private static InventoryDatabase mInventoryDB;

    public static InventoryDatabase getInstance(Context context) {
        if (mInventoryDB == null) {
            mInventoryDB = new InventoryDatabase(context);
        }
        return mInventoryDB;
    }

    public InventoryDatabase(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    private static final class InventoryDB {
        //table of inventory
        public static final String TABLE_INVENTORY = "inventory";
        //column of inventory name
        public static final String NAME_INVENTORY = "inventory_name";
        //column of inventory quantity
        public static final String NUM_INVENTORY = "inventory_quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + InventoryDB.TABLE_INVENTORY + " (" +
                InventoryDB.NAME_INVENTORY + " text," +
                InventoryDB.NUM_INVENTORY + " INTEGER) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists " + InventoryDB.TABLE_INVENTORY);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    //CRUD - R
    public List<Inventory> getInventory() {
        List<Inventory> inventories = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + InventoryDB.TABLE_INVENTORY;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            do {
                Inventory in = new Inventory();
                in.setID(cursor.getInt(0));
                in.setName(cursor.getString(1));
                in.setNum(cursor.getInt(3));
                inventories.add(in);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return inventories;
    }

    //CRUD - C
    public boolean addInventory(String inventoryName, int numInventory){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryDB.NAME_INVENTORY,inventoryName);
        values.put(InventoryDB.NUM_INVENTORY,numInventory);

        long id = db.insert(InventoryDB.TABLE_INVENTORY, null, values);
        return id != -1;
    }

    //CRUD - U
    public void updateInventory(Inventory inventory) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDB.NAME_INVENTORY, inventory.getName());
        values.put(InventoryDB.NUM_INVENTORY, inventory.getNum());
        db.update(InventoryDB.TABLE_INVENTORY, values,
                InventoryDB.NAME_INVENTORY + " = ?", new String[] { inventory.getName() });
    }

    //CRUD - D
    public void deleteInventory(String inventoryName) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(InventoryDB.TABLE_INVENTORY,
                InventoryDB.NAME_INVENTORY + " = " + inventoryName, null);
    }
}
