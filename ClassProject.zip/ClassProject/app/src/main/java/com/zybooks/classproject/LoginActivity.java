package com.zybooks.classproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private UserDatabase mUserDB;
    EditText userName;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userName = (EditText) findViewById(R.id.UserName);
        password = (EditText) findViewById(R.id.Password);
        mUserDB = UserDatabase.getInstance(getApplicationContext());
    }

    public void NewUserBTN(View view) {
        String sUserName = userName.getText().toString();
        String sPassword = password.getText().toString();

        //check if both text fields have input
        if(!sUserName.matches("") && !sPassword.matches("")){

            //checks if user exists
            if(!mUserDB.checkUser(sUserName)){

                mUserDB.addUser(sUserName,sPassword);
                ToastMessage("User Added");

            }else{
                //user does exist
                String msg = userName.getText() + " is already a user";
                ToastMessage(msg);

            }
        }else{
            //empty field
            ToastMessage("Please complete both fields");
        }
    }

    public void GoBTN(View view) {
       String sUserName = userName.getText().toString();
       String sPassword = password.getText().toString();

        if(!sUserName.matches("") && !sPassword.matches("")){
            //checks if user exists
            if(mUserDB.checkUser(sUserName)){
                //checks if password matches with username
                if(mUserDB.checkUserPassword(sUserName, sPassword)){
                    //Password matches
                    switchActivities();
                }else{
                    //Password doesn't match
                    ToastMessage("Password Incorrect");

                }
            }else{
                //user does NOT exist
                String msg = userName.getText() + " is not a user";
                ToastMessage(msg);
            }
        }else{
            //empty field
            ToastMessage("Please complete both fields");
        }
    }

    private void ToastMessage(String msg){
        Context context = getApplicationContext();
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, msg, duration);
        toast.show();
    }

    private void switchActivities() {
        Intent switchActivityIntent = new Intent(this, InventoryActivity.class);
        startActivity(switchActivityIntent);
    }
}