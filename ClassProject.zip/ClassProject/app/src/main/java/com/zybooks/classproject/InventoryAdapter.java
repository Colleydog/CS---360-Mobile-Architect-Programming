package com.zybooks.classproject;

public class InventoryAdapter {
}
