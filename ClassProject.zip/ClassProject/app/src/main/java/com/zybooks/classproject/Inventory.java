package com.zybooks.classproject;

public class Inventory {

    private String mName;
    private int mNum;
    private int mID;

    public Inventory(String mName, int mNum, int mID) {
        this.mName = mName;
        this.mNum = mNum;
        this.mID = mID;
    }
    public Inventory() {
    }

    public int getID() {
        return mID;
    }

    public void setID(int mID) {
        this.mID = mID;
    }

    public String getName() {
        return mName;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public int getNum() {
        return mNum;
    }

    public void setNum(int mNum) {
        this.mNum = mNum;
    }

}
